package com.baking.usersservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
